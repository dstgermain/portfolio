<?php include "includes/header.php";?>
<div class="home-bg">
<div class="save-the-date">Save the Date<span>May 30, 2015</span></div>
<div><p class="p-1 txt-ctr">The Multicultural Arts Center</p><p class="p-2 txt-ctr no-mrg">41 Second St,</p><p class="p-2 txt-ctr no-mrg">Cambridge, MA 02141</p></div>
</div>
<?php include "includes/footer.php";?>