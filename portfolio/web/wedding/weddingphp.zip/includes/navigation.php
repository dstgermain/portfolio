<li><a href="index.php">Home</a></li>
<li><a href="about.php">Susannah &amp; Dan</a></li>
<li><a href="venue.php">Venue</a></li>
<li><a href="rsvp.php">Event RSVP</a></li>
<li><a href="guestbook.php">Guestbook</a></li>
<li><a href="weddingparty.php">Wedding Party</a></li>
<li><a href="registry.php">Registry</a></li>
<li><a href="contact.php">Contact</a></li>