      </div>
      <div class="clear"></div>
      </div>
    <div class="clear"></div>
    <footer id="footer">
      <div class="content">
        <ul class="footer-navigation">
          <?php include "navigation.php" ?>
        </ul>
        <p>&copy; @DateTime.Now.Year - Daniel St. Germain</p>
      </div>
      <div class="clear"></div>
      <div class="corner left"></div>
      <div class="repeat bottom"></div>
      <div class="corner right"></div>
      <div class="clear"></div>
    </footer>
    <div class="clear"></div>
  </div>
</body>
</html>
